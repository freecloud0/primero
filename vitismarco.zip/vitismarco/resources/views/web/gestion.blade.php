@extends('layouts.app')

@section('content')
<!--Vista 02 ...........................................................................................-->
  
  <br>
  <br>
  <div class="container08 mt-8">
           <div class="row ">
             <div class="col-md-4 align-self-center text-center">
                 <img src="image/person1.jpg" class="image01">
             </div>
             <div class="col-md-8">
                 <div class="card-block margen01">
                   <h4 class="m-text22"><span class="m-textplus7m">CONSEJO DISTRITAL DE VITIS</span> </h4>
                   <P class="m-textplus7">GESTIÓN 2015-2018</P>
                   <br>
                   <p class="m-textplus10">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                   tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                   quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                   consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                   cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                   proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                   </p>
                   <br>
                   <p class="m-textplus8">Manuel P. Hinostroza Collachagua</p>
                   <p class="m-textplus9">ALCALDE</p>
                 </div>
             </div>
           </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <div class="container08">
      <div class="row">
        <div class="col-md-4 align-self-center text-center">
            <img src="image/person1.jpg" class="image02">
            <p class="m-textplus8">Manuel P. Hinostroza Collachagua</p>
                   <p class="m-textplus9">ALCALDE</p>
            <p></p>
            <br>
            <br>
        </div>
        <div class="col-md-4 align-self-center text-center">
            <img src="image/person1.jpg" class="image02">
            <p class="m-textplus8">Manuel P. Hinostroza Collachagua</p>
                   <p class="m-textplus9">ALCALDE</p>
            <p></p>
            <br>
            <br>
        </div>
        <div class="col-md-4 align-self-center text-center">
            <img src="image/person1.jpg" class="image02">
            <p class="m-textplus8">Manuel P. Hinostroza Collachagua</p>
                   <p class="m-textplus9">ALCALDE</p>
            <p></p>
            <br>
            <br>
        </div>
        <div class="col-md-4 align-self-center text-center">
            <img src="image/person1.jpg" class="image02">
            <p class="m-textplus8">Manuel P. Hinostroza Collachagua</p>
                   <p class="m-textplus9">ALCALDE</p>
            <p></p>
            <br>
            <br>
        </div>
        <div class="col-md-4 align-self-center text-center">
            <img src="image/person1.jpg" class="image02">
            <p class="m-textplus8">Manuel P. Hinostroza Collachagua</p>
                   <p class="m-textplus9">ALCALDE</p>
            <p></p>
            <br>
            <br>
        </div>
        <div class="col-md-4 align-self-center text-center">
            <img src="image/person1.jpg" class="image02">
            <p class="m-textplus8">Manuel P. Hinostroza Collachagua</p>
                   <p class="m-textplus9">ALCALDE</p>
            <p></p>
            <br>
            <br>
        </div>
        <div class="col-md-4 align-self-center text-center">
            <img src="image/person1.jpg" class="image02">
            <p class="m-textplus8">Manuel P. Hinostroza Collachagua</p>
                   <p class="m-textplus9">ALCALDE</p>
            <p></p>
            <br>
            <br>
        </div>
 
      </div>
    </div>


<!--Table-->

<h4 class="m-text22 align-self-center text-center"><span class="m-textplus7m">GESTIÓN Y PROYECTO</span></h4>

  <br>
  <br>


<div class="container">
  <!--Table-->
      <table class="table table-striped">

          <!--Table head-->
          <thead>
              <tr>
                  <th>#</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Username</th>
                  <th>Descargar</th>
              </tr>
          </thead>
          <!--Table head-->

          <!--Table body-->
          <tbody>
              <tr>
                  <th scope="row">1</th>
                  <td>Mark</td>
                  <td>Otto</td>
                  <td>@mdo</td>
                  <td><button type="button" class="descargas btn-danger btn-sm "><span class="m-textplus4">PDF</span></button></td>
              </tr>
              <tr>
                  <th scope="row">2</th>
                  <td>Jacob</td>
                  <td>Thornton</td>
                  <td>@fat</td>
                  <td><button type="button" class="descargas btn-danger btn-sm "><span class="m-textplus4">PDF</span></button></td>
              </tr>
              <tr>
                  <th scope="row">3</th>
                  <td>Larry</td>
                  <td>the Bird</td>
                  <td>@twitter</td>
                  <td><button type="button" class="descargas btn-danger btn-sm "><span class="m-textplus4">PDF</span></button></td>
              </tr>
          </tbody>
          <!--Table body-->

      </table>
      <!--Table-->

</div>
      













<br>

<div class=" container text-center align-self-center">
        <p class="lead">
          <a class="text-center align-self-center" href=" " role="button">
            <i class="fa fa-chevron-circle-down fa-3x" aria-hidden="true"></i>
          </a>
        </p>
</div>
        
<br>

@endsection
