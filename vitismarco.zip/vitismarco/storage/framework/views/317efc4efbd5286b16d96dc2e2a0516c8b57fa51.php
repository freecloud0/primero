<?php $__env->startSection('content'); ?>
















<br><br>






   




<div class="container09">
  <br>
	<div class="texttitulo-b align-self-center text-center"> FAQS
	</div>
	<div class="linea01"></div>
	<br>
	<h3 class="align-self-center text-center">Resolvemos tus dudas</h3>	


	<br><br>


</div>



<div class="container09">
    <div class="texttitulo-g align-self-center m-t-10"> GENERAL
    </div>
    <br>

    <!--Accordion wrapper-->
    <div class="accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
    
        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i id="btn-exp" class="m-l-40 fa fa-minus-circle"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1">
                            <i id="btn-exp" class="fa fa-plus-circle"></i>
                          </div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapseOne" class="collapse show" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordionEx" >
                <div class="card-body marg-20">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i id="btn-exp" class="m-l-40 fa fa-plus-circle"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapseTwo" class="collapse" role="tabpanel" aria-labelledby="headingTwo" data-parent="#accordionEx" >
                <div class="card-body marg-20">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapseThree" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body marg-20">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

           <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse4" aria-expanded="true" aria-controls="collapse4">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse4" aria-expanded="true" aria-controls="collapse4">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse4" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

           <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse5" aria-expanded="true" aria-controls="collapse5">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse5" aria-expanded="true" aria-controls="collapse5">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse5" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->




        <br>
        <div class="texttitulo-g align-self-center m-t-10"> ACERCA DE HOSPEDAJES
        </div>
        <br>

        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse6" aria-expanded="true" aria-controls="collapse6">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse6" aria-expanded="true" aria-controls="collapse6">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse6" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
       <!-- Accordion card -->
        <div class="card">

            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse7" aria-expanded="true" aria-controls="collapse7">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse7" aria-expanded="true" aria-controls="collapse7">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse7" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse8" aria-expanded="true" aria-controls="collapse8">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse8" aria-expanded="true" aria-controls="collapse8">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse8" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse9" aria-expanded="true" aria-controls="collapse9">
                    <h5 class="mb-0">
                        <div class="row text-white" >
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse9" aria-expanded="true" aria-controls="collapse9">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>
            <!-- Card body -->
            <div id="collapse9" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

           <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse10" aria-expanded="true" aria-controls="collapse10">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse10" aria-expanded="true" aria-controls="collapse10">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse10" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->

        <br>
        <div class="texttitulo-g align-self-center m-t-10"> ACERCA DE COMIDAS
        </div>
        <br>
        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse11" aria-expanded="true" aria-controls="collapse11">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse11" aria-expanded="true" aria-controls="collapse11">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse11" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
       <!-- Accordion card -->
        <div class="card">

           
            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse12" aria-expanded="true" aria-controls="collapse12">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse12" aria-expanded="true" aria-controls="collapse12">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse12" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

           <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse13" aria-expanded="true" aria-controls="collapse13">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse13" aria-expanded="true" aria-controls="collapse13">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse13" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse14" aria-expanded="true" aria-controls="collapse14">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse14" aria-expanded="true" aria-controls="collapse14">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse14" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse15" aria-expanded="true" aria-controls="collapse15">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse15" aria-expanded="true" aria-controls="collapse15">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse15" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->

        <br>
        <div class="texttitulo-g align-self-center m-t-10"> ACERCA DE SITIOS DE INTERÉS
        </div>
        <br>
        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse16" aria-expanded="true" aria-controls="collapse16">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse16" aria-expanded="true" aria-controls="collapse16">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse16" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
       <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse17" aria-expanded="true" aria-controls="collapse17">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse17" aria-expanded="true" aria-controls="collapse17">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse17" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse18" aria-expanded="true" aria-controls="collapse18">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse18" aria-expanded="true" aria-controls="collapse18">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse18" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse19" aria-expanded="true" aria-controls="collapse19">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse19" aria-expanded="true" aria-controls="collapse19">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse19" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->
        <br>
        <!-- Accordion card -->
        <div class="card">

            <!-- Card header -->
            <!-- Card header -->
            <div class="card-header blue visible01" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse20" aria-expanded="true" aria-controls="collapse20">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-8 marg-20"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-3"></div>
                          <i class="m-l-40 fa fa-plus-circle" aria-hidden="true"></i>
                        </div>
                    </h5>
                </a>
            </div>

            <div class="card-header blue visible" role="tab" id="headingOne">
                <a data-toggle="collapse" href="#collapse20" aria-expanded="true" aria-controls="collapse20">
                    <h5 class="mb-0">
                        <div class="row text-white">
                          <div class="col-10"> ¿Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum ? </div>
                          <div class="col-1"><i class="fa fa-plus-circle" aria-hidden="true"></i></div>
                          
                        </div>
                    </h5>
                </a>
            </div>

            <!-- Card body -->
            <div id="collapse20" class="collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordionEx">
                <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute,
                    non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf
                    moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch
                    et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                    Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic
                    synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                </div>
            </div>
        </div>
        <!-- Accordion card -->

      </div>
</div> 
  
    <!--/.Accordion wrapper-->
                


<br><br>








<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>

        <!---------Efecto de boton  -------->
        <script>
          

            $(document).ready(function () {
              $("i").on("click", function () {
                 $(this).toggleClass('fa-minus-circle').toggleClass('fa-plus-circle');
              });
          });

        </script>

        <!---------Efecto de boton  -------->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>