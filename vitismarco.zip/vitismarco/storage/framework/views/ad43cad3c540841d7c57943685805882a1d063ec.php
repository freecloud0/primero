<?php $__env->startSection('content'); ?>



<div class="container">
	<!-- Projects section v.3 -->
	<section class="my-5">

	  <!-- Section heading -->

				<!-- Grid row -->
				<div class="row">

					    <!-- Grid column -->
					    <div class="col-lg-5 mb-lg-0 mb-5">
					      <!--Image-->
					      
					      	<div class="view">
							    <img src="https://mdbootstrap.com/img/Photos/Others/forest-sm.jpg" class="img-fluid" alt="placeholder">
							     <a>
				                   <li data-toggle="modal" onclick="lightbox(0)" class="active"><div class="mask rgba-white-slight" ></div></li>
				                  </a>
				              

							</div>

										


				                
					    </div>
					    <!-- Grid column -->
					    <div class="linea-v01 visible01 m-l-95"></div>
					    <!-- Grid column -->
					    <div class="col-lg-6">

					      <!-- Grid row -->
					      <div class="row  mb-3">
					        <div class="container">
					        	<h6 class="text-center">1 de julio - 4 de agosto</h6>
					           <h4 class="text-center">"Our best projects"</h4>
					           <h4 class="text-center">Apostol SANTIAGO</h4>
					           <br>
					           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					           tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					           quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					           consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					           cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					           proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					           <br>
							    <a href="#" class="btn btn-verde btn-sm redondear mt-4 ">Button</a>

					  			<!-- Section description -->
					        </div>
					      </div>

					    </div>
					    <!-- Grid column -->

				</div>
				<!-- Grid row -->


	 <hr class="my-5"> <!----division --->




				 <!-- Grid row -->
				<div class="row">

					    <!-- Grid column -->
					    <div class="col-lg-6">

					      <!-- Grid row -->
					      <div class="row  mb-3">
					        <div class="container">
					        	<h6 class="text-center">1 de julio - 4 de agosto</h6>
					           <h4 class="text-center">"Our best projects"</h4>
					           <h4 class="text-center">Apostol SANTIAGO</h4>
					           <br>
					           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					           tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					           quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					           consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					           cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					           proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					           <br>
							    <a href="#" class="btn btn-verde btn-sm redondear mt-4 ">Button</a>
								
					  			<!-- Section description -->
					        </div>
					      </div>

					    </div>
					    <!-- Grid column -->
					    <div class="linea-v01 visible01 m-r-95"></div>
					    <!-- Grid column -->
					    <div class="col-lg-5">
					      <!--Image-->
					      <div class="view">
					      	<img src="https://mdbootstrap.com/img/Photos/Others/images/82.jpg" alt="Sample project image" class="img-fluid rounded z-depth-1">
					      			<a>
				                   <li data-toggle="modal" onclick="lightbox(2)" class="active"><div class="mask rgba-white-slight" ></div></li>
				                  </a>
				            
					      </div>
					      	
					    </div>
					    <!-- Grid column -->

				</div>
				 <!-- Grid row -->

     <hr class="my-5"> <!----division --->

				<!-- Grid row -->
				<div class="row">

					    <!-- Grid column -->
					    <div class="col-lg-5 mb-lg-0 mb-5">
					      <!--Image-->
					      
					      	<div class="view">
							    <img src="https://mdbootstrap.com/img/Photos/Others/forest-sm.jpg" class="img-fluid" alt="placeholder">
							     <a>
				                   <li data-toggle="modal" onclick="lightbox(0)" class="active"><div class="mask rgba-white-slight" ></div></li>
				                  </a>
				              

							</div>

										


				                
					    </div>
					    <!-- Grid column -->
					    <div class="linea-v01 visible01 m-l-95"></div>
					    <!-- Grid column -->
					    <div class="col-lg-6">

					      <!-- Grid row -->
					      <div class="row  mb-3">
					        <div class="container">
					        	<h6 class="text-center">1 de julio - 4 de agosto</h6>
					           <h4 class="text-center">"Our best projects"</h4>
					           <h4 class="text-center">Apostol SANTIAGO</h4>
					           <br>
					           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					           tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					           quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					           consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					           cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					           proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					           <br>
							    <a href="#" class="btn btn-verde btn-sm redondear mt-4 ">Button</a>

					  			<!-- Section description -->
					        </div>
					      </div>

					    </div>
					    <!-- Grid column -->

				</div>
				<!-- Grid row -->


	 <hr class="my-5"> <!----division --->




				 <!-- Grid row -->
				<div class="row">

					    <!-- Grid column -->
					    <div class="col-lg-6">

					      <!-- Grid row -->
					      <div class="row  mb-3">
					        <div class="container">
					        	<h6 class="text-center">1 de julio - 4 de agosto</h6>
					           <h4 class="text-center">"Our best projects"</h4>
					           <h4 class="text-center">Apostol SANTIAGO</h4>
					           <br>
					           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					           tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					           quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					           consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					           cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					           proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					           <br>
							    <a href="#" class="btn btn-verde btn-sm redondear mt-4 ">Button</a>
								
					  			<!-- Section description -->
					        </div>
					      </div>

					    </div>
					    <!-- Grid column -->
					    <div class="linea-v01 visible01 m-r-95"></div>
					    <!-- Grid column -->
					    <div class="col-lg-5">
					      <!--Image-->
					      <div class="view">
					      	<img src="https://mdbootstrap.com/img/Photos/Others/images/82.jpg" alt="Sample project image" class="img-fluid rounded z-depth-1">
					      			<a>
				                   <li data-toggle="modal" onclick="lightbox(2)" class="active"><div class="mask rgba-white-slight" ></div></li>
				                  </a>
				            
					      </div>
					      	
					    </div>
					    <!-- Grid column -->

				</div>
				 <!-- Grid row -->


	</section>
	<!-- Projects section v.3 -->           
</div>


	
 <!--Galeria de imagenes a mostrar en slider-->
    <div style="display:none;">
        <div id="ninja-slider">
            <div class="slider-inner">
                <ul>
                    <li>
                        <a class="" ><img class="card-img-top mt-4 border-ima" src="https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(67).jpg" alt="Card image cap"></a>
                        <div class="caption-01">
                            <h3>Dummy Caption 1</h3>
                            <p class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus accumsan purus.</p>
                        </div>
                    </li>
                    <li>
                        <a class="" ><img class="card-img-top mt-4 border-ima" src="https://mdbootstrap.com/img/Photos/Others/images/43.jpg" alt="Card image cap"></a>
                        <div class="caption-01">
                            <h3>Dummy Caption 1</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus accumsan purus.</p>
                        </div>
                    </li>
                    <li>
                        <a class="" ><img class="card-img-top mt-4 border-ima" src="https://mdbootstrap.com/img/Photos/Others/photo6.jpg" alt="Card image cap"></a>
                        <div class="caption-01">
                            <h3>Dummy Caption 1</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus accumsan purus.</p>
                        </div>
                    </li>
                    <li>
                        <a class="" ><img class="card-img-top mt-4 border-ima" src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(147).jpg" alt="Card image cap"></a>
                        <div class="caption-01">
                            <h3>Dummy Caption 1</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus accumsan purus.</p>
                        </div>
                    </li>
                    <li>
                        <a class="" ><img class="card-img-top mt-4 border-ima" src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20%28131%29.jpg" alt="Card image cap"></a>
                        <div class="caption-01">
                            <h3>Dummy Caption 1</h3>
                            <p class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus accumsan purus.</p>
                        </div>
                    </li>
                </ul>
                <div id="fsBtn" class="fs-icon" title="CERRAR"></div>
            </div>
        </div>
    </div>





                         






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>