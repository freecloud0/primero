<?php $__env->startSection('content'); ?>


<div class="container12">
	
	<br><br>
	<img class="image05 d-block " src="<?php echo e(asset('images/galeria/parallax2.jpg')); ?>" alt="Second slide">
	<br>
	<br>



</div>

<div class="container07">
	<p class="lead  m-textplus"><strong>A la palabra VITIS, se le asigna varios orígenes siendo:</strong> </p>
	
	<p class="lead  m-textplus">Quienes aseguran que el origen es quechua, se basan en que la mayoría de los habitantes padecen del enroecimiento y lagrimeo de los ojos a consecuencia de los vientos que reina en el pueblo, debido a su ubicación geográfica.<br />
	Los que fundamentan elorigen del jakaro, se basan en que el pueblo estuvo poblado por gente de fuera o sea de WITIS.
	Según manifestaba el padre redentorista Carmelo en su visita pastoral al pueblo de Vitis, en el año 1947, la palabra VITIS tiene origen latín VID osea VIDA, por su gente buena que da vida, tal como él observó la vez que estuvo en el pueblo: hospitalario y que da vida.</p>
	
	<p class="lead  m-textplus">Quienes aseguran que el origen es quechua, se basan en que la mayoría de los habitantes padecen del enroecimiento y lagrimeo de los ojos a consecuencia de los vientos que reina en el pueblo, debido a su ubicación geográfica.<br />
	Los que fundamentan elorigen del jakaro, se basan en que el pueblo estuvo poblado por gente de fuera o sea de WITIS.
	Según manifestaba el padre redentorista Carmelo en su visita pastoral al pueblo de Vitis, en el año 1947, la palabra VITIS tiene origen latín VID osea VIDA, por su gente buena que da vida, tal como él observó la vez que estuvo en el pueblo: hospitalario y que da vida.</p>
	<p class="lead  m-textplus">Quienes aseguran que el origen es quechua, se basan en que la mayoría de los habitantes padecen del enroecimiento y lagrimeo de los ojos a consecuencia de los vientos que reina en el pueblo, debido a su ubicación geográfica.<br />
	Los que fundamentan elorigen del jakaro, se basan en que el pueblo estuvo poblado por gente de fuera o sea de WITIS.
	Según manifestaba el padre redentorista Carmelo en su visita pastoral al pueblo de Vitis, en el año 1947, la palabra VITIS tiene origen latín VID osea VIDA, por su gente buena que da vida, tal como él observó la vez que estuvo en el pueblo: hospitalario y que da vida.</p>

</div>
<br>
<div class="container09">
	<div class=" align-self-center text-center"> 
		<p class="texttitulo-b">¿Te ha gustado? Compártelo o comenta</p>

      <div class="text-center mt-4">
        <a href="#" class="text-white fa fa-facebook-square fa-2x indigo-text mr-4"></a>
        <a href="#" class="text-white fa fa-google-plus fa-2x red-text"></a>
        <a href="#" class="text-white fa fa fa-instagram fa-2x green-text ml-4"></a>
      </div>
      <div class="linea02 mt-4"></div>
      <br>
      	<div class="text-center mt-4">
      		<li class="list-inline-item pr-2 esp-02"><a href=""><i class=" fa fa-thumbs-up" aria-hidden="true"></i></a>15</li>

			<li class="list-inline-item pr-2"><a href=""><i class=" fa fa-comments-o" aria-hidden="true"></i></a>12</li>
      	</div>
      
      <div class="linea02 mt-4"></div>

         	  	 
	</div>
	
</div>
<br>
        <div class="container07 mt-4">
        	<div class="row">
        		<div class="col-ms-4"></div>
        			<div class="m-t-40">
        				<img src="image/person1.jpg" class="image07 redondear">
        			</div>
        			
        		<div class="col-8 ">
        			<div class="m-l-50">
        				<p class="mb-4">Dejar un comentario</p>
		        	<textarea class="form-control" id="exampleFormControlTextarea1" rows="5"></textarea>
		        	<button type="button" class="btn btn-blue-grey mt-4">Responder</button>
        			</div>
        			

        		</div>
        	</div>
        	
        </div> 
<br><br>
	

	







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>